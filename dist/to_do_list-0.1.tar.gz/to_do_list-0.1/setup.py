from setuptools import setup

setup(name = 'to_do_list', 
	version = '0.1',
	description = 'Package for maintaining to-do lists',
	packages = ['to_do_list'],
	author = 'Ayushi Vishwakarma',
	author_email = 'ayushivishwakarma22@gmail.com',
	zip_safe = False)